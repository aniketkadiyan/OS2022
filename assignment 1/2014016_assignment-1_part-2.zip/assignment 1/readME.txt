
the integer input and printing and string input and printing are two different programs
please go to each individual directory and make them there
makefiles are included
